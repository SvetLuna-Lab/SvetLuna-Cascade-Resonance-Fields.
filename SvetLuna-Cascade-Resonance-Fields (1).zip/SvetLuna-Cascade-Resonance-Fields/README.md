# 🌌 SvetLuna — Cascade Resonance Fields
Modeling the propagation of dark energy through spectral resonance layers.  
Part of the SvetLuna Research Continuum (2025).

## 🧭 Overview
This simulation explores how energy resonance travels through layered fields —
how frequency coherence is preserved even when amplitude decays.
It visualizes the dynamic “breathing” of dark energy across multiple spectral levels.

## ⚙️ Run
```bash
make setup
make run
make plots
```

Outputs are stored in `outputs/figures/`.

© 2025 Svetlana Romanova (SvetLuna)
