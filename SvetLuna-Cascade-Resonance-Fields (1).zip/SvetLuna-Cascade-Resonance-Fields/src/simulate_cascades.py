import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

Path("outputs/figures").mkdir(parents=True, exist_ok=True)

def generate_layer(freq_shift, phase_shift, amplitude=1.0, noise_level=0.2):
    x = np.linspace(0, 10, 2000)
    wave = amplitude * np.sin(2 * np.pi * (x * freq_shift) + phase_shift)
    noise = np.random.normal(0, noise_level, len(x))
    return wave + noise

layers = []
for i in range(1, 6):
    layers.append(generate_layer(i * 0.25, i * np.pi / 6, amplitude=1 / i))

cascade = np.sum(layers, axis=0)

plt.figure(figsize=(12, 5))
plt.plot(cascade)
plt.title("Cascade Resonance Field — Simulated Dark Energy Flow")
plt.xlabel("Spatial coordinate (normalized)")
plt.ylabel("Resonance amplitude")
plt.tight_layout()
plt.savefig("outputs/figures/cascade_field.png", dpi=300)
plt.close()
